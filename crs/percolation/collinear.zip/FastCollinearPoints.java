/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class FastCollinearPoints {
    private final Point[] points;

    public FastCollinearPoints(Point[] points) {
        if (Objects.isNull(points)) {
            throw new IllegalArgumentException("Points arr cannot be null");
        }
        for (Point point : points) {
            if (Objects.isNull(point)) {
                throw new IllegalArgumentException("Point cannot be null");
            }
        }
        this.points = new Point[points.length];
        System.arraycopy(points, 0, this.points, 0, points.length);
    }
    public int numberOfSegments() {
        return segments().length;
    }

    public LineSegment[] segments() {
        Point[] newPoints = new Point[points.length];
        List<LineSegment> list = new ArrayList<>();
        LineSegment[] lineSegmentArr;
        System.arraycopy(points, 0, newPoints, 0, points.length);
        for (int i = 0; i < newPoints.length; i++) {
            Point p = newPoints[i];
            Arrays.sort(points, p.slopeOrder());
            // for (int j = 0; j < points.length; j++) {
            //
            // }
        }
        lineSegmentArr = new LineSegment[list.size()];
        int count = 0;
        list.forEach(segment -> {
            lineSegmentArr[count] = segment;
        });
        return lineSegmentArr;
    }

    public static void main(String[] args) {
        // empty method body
    }
}

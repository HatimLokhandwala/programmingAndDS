/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class BruteCollinearPoints {
    private final Point[] points;

    public BruteCollinearPoints(Point[] points) {
        if (Objects.isNull(points)) {
            throw new IllegalArgumentException("Points arr cannot be null");
        }
        for (Point point : points) {
            if (Objects.isNull(point)) {
                throw new IllegalArgumentException("Point cannot be null");
            }
        }
        this.points = new Point[points.length];
        System.arraycopy(points, 0, this.points, 0, points.length);
    }

    public int numberOfSegments() {
        return segments().length;
    }

    public LineSegment[] segments() {
        int len = points.length;
        List<LineSegment> list = new ArrayList<>();
        LineSegment[] lineSegmentArr;
        for (int i = 0; i < len; i++) {
            for (int j = i + 1; j < len; j++) {
                for (int k = j + 1; k < len; k++) {
                    for (int p = k + 1; p < len; p++) {
                        double slope1 = points[i].slopeTo(points[j]);
                        double slope2 = points[j].slopeTo(points[k]);
                        if (Math.abs(slope1 - slope2) > 0.01) {
                            continue;
                        }

                        double slope3 = points[k].slopeTo(points[p]);
                        if (Math.abs(slope2 - slope3) > 0.01) {
                            continue;
                        }
                        LineSegment lineSegment = new LineSegment(points[i], points[p]);
                        list.add(lineSegment);
                    }
                }
            }
        }
        lineSegmentArr = new LineSegment[list.size()];
        int count = 0;
        list.forEach(segment -> {
            lineSegmentArr[count] = segment;
        });
        return lineSegmentArr;
    }

    public static void main(String[] args) {
        // empty method body
    }
}
